@echo off
cd /d "%~dp0"
echo === Step 1/3: building DynamicIsland.exe ===
call build.bat nopause
if errorlevel 1 goto fail
if not exist dist\DynamicIsland.exe goto fail

echo.
echo === Step 2/3: looking for Inno Setup ===
set "ISCC="
call :find
if defined ISCC goto build
echo Inno Setup not found - trying to install it with winget...
winget install -e --id JRSoftware.InnoSetup --silent --accept-package-agreements --accept-source-agreements
call :find
if defined ISCC goto build
echo ERROR: Inno Setup is not installed. Download it from https://jrsoftware.org/isdl.php , install it, then run this file again.
goto fail

:build
echo.
echo === Step 3/3: creating the installer ===
"%ISCC%" setup.iss
if errorlevel 1 goto fail
echo.
echo Done! Installer: installer\DynamicIsland-Setup.exe
pause
exit /b 0

:find
if exist "%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe" set "ISCC=%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe"
if exist "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if exist "%ProgramFiles%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles%\Inno Setup 6\ISCC.exe"
exit /b 0

:fail
echo.
echo Setup build failed. Scroll up to read the first error message.
pause
exit /b 1
